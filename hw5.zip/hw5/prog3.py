def square(x):
    return x*x

def notmap(func,list):
    for element in list:
        yield func(element)

for element in notmap(square,range(5)):
    print (element)
