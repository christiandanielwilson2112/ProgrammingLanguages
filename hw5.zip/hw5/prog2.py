def decimate_list_gen(original_list,factor):
    i = 0
    for element in original_list:
        if i%factor == 0 :
            yield element
        i += 1

for element in decimate_list_gen(range(10),3 ) :
    print (element)
