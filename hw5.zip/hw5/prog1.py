def decimate_list(original_list, factor):
    decimated_list = []
    for i in original_list: 
        if i%factor == 0:
            decimated_list.append(i)    
    return decimated_list

print (decimate_list(range(10), 3)) #prints [0, 3, 6, 9]
