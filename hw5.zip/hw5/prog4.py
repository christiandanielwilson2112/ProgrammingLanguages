def even(x):
    if x%2 == 0:
       return x 
    
     
def notfilter(func,list):
    for element in list:
        if isinstance(func(element),int):
            yield func(element)
            
for element in notfilter(even,range(5)):
    print (element)

